export declare const outerWidth: (el: HTMLElement) => number;
//# sourceMappingURL=dimensions.d.ts.map
declare const _default: () => Document;
export default _default;
//# sourceMappingURL=document.d.ts.map
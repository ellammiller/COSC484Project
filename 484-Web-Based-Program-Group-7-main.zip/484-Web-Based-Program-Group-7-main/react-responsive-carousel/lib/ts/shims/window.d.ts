declare const _default: () => Window & typeof globalThis;
export default _default;
//# sourceMappingURL=window.d.ts.map
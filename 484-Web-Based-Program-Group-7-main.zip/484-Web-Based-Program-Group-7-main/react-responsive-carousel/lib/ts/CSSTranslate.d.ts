declare const _default: (position: number, metric: 'px' | '%', axis: 'horizontal' | 'vertical') => string;
export default _default;
//# sourceMappingURL=CSSTranslate.d.ts.map
export { default as Carousel } from './components/Carousel';
export { default as Thumbs } from './components/Thumbs';
//# sourceMappingURL=index.d.ts.map